const express = require("express");
const asyncHandler = require("../utils/asyncHandler");
const { requireAuth } = require("../middleware/auth");
const paymentService = require("../services/paymentService");
const db = require("../db");

const router = express.Router();
router.use(requireAuth);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    res.json(paymentService.listPayments(req.userId));
  })
);

router.post(
  "/premium",
  asyncHandler(async (req, res) => {
    const user = db.prepare(`SELECT is_premium FROM users WHERE id = ?`).get(req.userId);
    if (user.is_premium) return res.status(409).json({ error: "Already premium" });
    paymentService.unlockPremium(req.userId);
    res.status(201).json({ isPremium: true });
  })
);

module.exports = router;
