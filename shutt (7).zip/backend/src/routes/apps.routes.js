const express = require("express");
const asyncHandler = require("../utils/asyncHandler");
const { requireAuth } = require("../middleware/auth");
const appService = require("../services/appService");
const shuttService = require("../services/shuttService");

const router = express.Router();
router.use(requireAuth);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    shuttService.sweepExpired(req.userId);
    const apps = appService.listAppsForUser(req.userId);
    const withStatus = apps.map((a) => {
      const active = shuttService.activeShuttForApp(req.userId, a.id);
      return {
        id: a.id,
        name: a.name,
        category: a.category,
        color: a.color,
        iconKey: a.icon_key,
        status: active ? "locked" : "available",
        unlockAt: active ? active.unlock_at : null,
        durationMs: active ? active.duration_ms : null,
        shuttId: active ? active.id : null,
      };
    });
    res.json(withStatus);
  })
);

// A curated list of real, well-known apps the user can pick from — see the
// note in appService.js on why this exists instead of reading the phone's
// actual installed-app list (no web API can).
router.get(
  "/catalog",
  asyncHandler(async (req, res) => {
    res.json(appService.getCatalog());
  })
);

router.post(
  "/import",
  asyncHandler(async (req, res) => {
    const { ids } = req.body || {};
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: "ids must be a non-empty array of catalog app ids" });
    }
    const apps = appService.importApps(req.userId, ids);
    res.status(201).json(apps);
  })
);

router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { name, category, color, iconKey } = req.body || {};
    if (!name) return res.status(400).json({ error: "name is required" });
    const app = appService.createApp(req.userId, { name, category, color, iconKey });
    res.status(201).json(app);
  })
);

module.exports = router;
