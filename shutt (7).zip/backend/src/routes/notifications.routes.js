const express = require("express");
const asyncHandler = require("../utils/asyncHandler");
const { requireAuth } = require("../middleware/auth");
const notificationService = require("../services/notificationService");
const shuttService = require("../services/shuttService");
const sessionService = require("../services/sessionService");

const router = express.Router();
router.use(requireAuth);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    shuttService.sweepExpired(req.userId);
    sessionService.sweepExpiredSessions(req.userId);
    res.json({
      notifications: notificationService.list(req.userId),
      unread: notificationService.unreadCount(req.userId),
    });
  })
);

router.post(
  "/read-all",
  asyncHandler(async (req, res) => {
    notificationService.markAllRead(req.userId);
    res.json({ ok: true });
  })
);

module.exports = router;
