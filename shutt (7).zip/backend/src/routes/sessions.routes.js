const express = require("express");
const asyncHandler = require("../utils/asyncHandler");
const { requireAuth } = require("../middleware/auth");
const sessionService = require("../services/sessionService");
const { findNudgeDuration } = require("../utils/durations");

const router = express.Router();
router.use(requireAuth);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    res.json(sessionService.listActiveSessions(req.userId));
  })
);

// call when the user opens an app normally (not a hard shutt)
router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { appId } = req.body || {};
    if (!appId) return res.status(400).json({ error: "appId is required" });
    sessionService.sweepExpiredSessions(req.userId);
    const session = sessionService.startSession(req.userId, appId);
    res.status(201).json(session);
  })
);

router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    sessionService.sweepExpiredSessions(req.userId);
    const session = sessionService.getSession(req.userId, req.params.id);
    if (!session) return res.status(404).json({ error: "Session not found" });
    res.json(session);
  })
);

// body: either { durationKey } from the nudge presets, or a raw { limitMs }
router.patch(
  "/:id/limit",
  asyncHandler(async (req, res) => {
    const { durationKey, limitMs } = req.body || {};
    let ms = limitMs;
    if (durationKey) {
      const preset = findNudgeDuration(durationKey);
      if (!preset) return res.status(400).json({ error: "Unknown durationKey" });
      ms = preset.ms;
    }
    if (!ms || ms <= 0) return res.status(400).json({ error: "A valid limitMs or durationKey is required" });
    const session = sessionService.setLimit(req.userId, req.params.id, ms);
    res.json(session);
  })
);

router.post(
  "/:id/end",
  asyncHandler(async (req, res) => {
    const session = sessionService.endSession(req.userId, req.params.id, "manual");
    if (!session) return res.status(404).json({ error: "Active session not found" });
    res.json(session);
  })
);

module.exports = router;
