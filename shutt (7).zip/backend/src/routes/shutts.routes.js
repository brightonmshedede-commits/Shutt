const express = require("express");
const asyncHandler = require("../utils/asyncHandler");
const { requireAuth } = require("../middleware/auth");
const shuttService = require("../services/shuttService");
const { PREMIUM_PRICE } = require("../utils/durations");

const router = express.Router();
router.use(requireAuth);

router.get(
  "/active",
  asyncHandler(async (req, res) => {
    res.json(shuttService.listActiveShutts(req.userId));
  })
);

// Full history (active, ended, emergency-unlocked) — powers the stats screen.
router.get(
  "/",
  asyncHandler(async (req, res) => {
    res.json(shuttService.listAllShutts(req.userId));
  })
);

// body: { items: [{ appId, durationKey }] }
// One entry per app being shutt. Send the same durationKey for every item
// for "same duration for all", or different keys per item for per-app times.
router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { items } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "items must be a non-empty array of { appId, durationKey }" });
    }
    try {
      const created = shuttService.createShutts(req.userId, items);
      res.status(201).json({ created });
    } catch (err) {
      if (err.premiumRequired) {
        return res.status(402).json({
          error: err.message,
          premiumRequired: true,
          plan: err.plan,
          premiumPrice: PREMIUM_PRICE,
        });
      }
      throw err;
    }
  })
);

router.post(
  "/:id/emergency-unlock",
  asyncHandler(async (req, res) => {
    const shutt = shuttService.emergencyUnlock(req.userId, req.params.id);
    res.json({ shutt });
  })
);

module.exports = router;
