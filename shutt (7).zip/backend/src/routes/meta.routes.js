const express = require("express");
const { DURATIONS, NUDGE_DURATIONS, PREMIUM_PRICE, EMERGENCY_PRICE } = require("../utils/durations");

const router = express.Router();

router.get("/", (req, res) => {
  res.json({
    durations: DURATIONS,
    nudgeDurations: NUDGE_DURATIONS,
    premiumPrice: PREMIUM_PRICE,
    emergencyPrice: EMERGENCY_PRICE,
  });
});

module.exports = router;
