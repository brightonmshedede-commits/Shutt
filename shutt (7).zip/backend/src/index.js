const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");

const { port } = require("./config");
const { notFound, errorHandler } = require("./middleware/errorHandler");
const { startSweeper } = require("./sweeper");

const authRoutes = require("./routes/auth.routes");
const appsRoutes = require("./routes/apps.routes");
const shuttsRoutes = require("./routes/shutts.routes");
const sessionsRoutes = require("./routes/sessions.routes");
const paymentsRoutes = require("./routes/payments.routes");
const notificationsRoutes = require("./routes/notifications.routes");
const metaRoutes = require("./routes/meta.routes");

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// auth endpoints get a tighter rate limit — signup/login are the classic
// brute-force targets
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30 });
app.use("/api/auth", authLimiter);

app.get("/health", (req, res) => res.json({ ok: true, time: Date.now() }));

app.use("/api/auth", authRoutes);
app.use("/api/apps", appsRoutes);
app.use("/api/shutts", shuttsRoutes);
app.use("/api/sessions", sessionsRoutes);
app.use("/api/payments", paymentsRoutes);
app.use("/api/notifications", notificationsRoutes);
app.use("/api/meta", metaRoutes);

app.use(notFound);
app.use(errorHandler);

app.listen(port, () => {
  console.log(`shutt backend listening on http://localhost:${port}`);
  startSweeper();
});
