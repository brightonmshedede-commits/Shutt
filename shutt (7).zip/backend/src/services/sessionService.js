const crypto = require("crypto");
const db = require("../db");
const notifications = require("./notificationService");

function startSession(userId, appId) {
  const activeShutt = db
    .prepare(`SELECT id FROM shutts WHERE user_id = ? AND app_id = ? AND status = 'active'`)
    .get(userId, appId);
  if (activeShutt) {
    const err = new Error("This app is currently shutt — end the restriction before starting a soft session");
    err.status = 409;
    throw err;
  }

  // One active session per app, same rule as shutts — starting a new one
  // quietly replaces any session already running for this app.
  const existing = db
    .prepare(`SELECT id FROM sessions WHERE user_id = ? AND app_id = ? AND status = 'active'`)
    .get(userId, appId);
  if (existing) {
    db.prepare(`UPDATE sessions SET status = 'ended', ended_at = ? WHERE id = ?`).run(Date.now(), existing.id);
  }

  const id = crypto.randomUUID();
  const now = Date.now();
  db.prepare(
    `INSERT INTO sessions (id, user_id, app_id, started_at, limit_ms, ended_at, status, created_at)
     VALUES (?, ?, ?, ?, NULL, NULL, 'active', ?)`
  ).run(id, userId, appId, now, now);
  return getSession(userId, id);
}

function listActiveSessions(userId) {
  sweepExpiredSessions(userId);
  return db
    .prepare(`SELECT * FROM sessions WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC`)
    .all(userId);
}

function getSession(userId, sessionId) {
  return db.prepare(`SELECT * FROM sessions WHERE id = ? AND user_id = ?`).get(sessionId, userId);
}

function setLimit(userId, sessionId, limitMs) {
  const session = db
    .prepare(`SELECT * FROM sessions WHERE id = ? AND user_id = ? AND status = 'active'`)
    .get(sessionId, userId);
  if (!session) {
    const err = new Error("Active session not found");
    err.status = 404;
    throw err;
  }
  const now = Date.now();
  db.prepare(`UPDATE sessions SET limit_ms = ?, started_at = ? WHERE id = ?`).run(limitMs, now, session.id);
  return getSession(userId, session.id);
}

function endSession(userId, sessionId, reason) {
  const session = db
    .prepare(`SELECT * FROM sessions WHERE id = ? AND user_id = ? AND status = 'active'`)
    .get(sessionId, userId);
  if (!session) return null;
  db.prepare(`UPDATE sessions SET status = 'ended', ended_at = ? WHERE id = ?`).run(Date.now(), session.id);
  if (reason === "limit") {
    const app = db.prepare(`SELECT name FROM apps WHERE id = ?`).get(session.app_id);
    notifications.push(
      userId,
      "session",
      `${app ? app.name : "Session"} ended — time's up, back to your home screen`
    );
  }
  return getSession(userId, session.id);
}

function sweepExpiredSessions(userId) {
  const now = Date.now();
  const active = db
    .prepare(`SELECT * FROM sessions WHERE user_id = ? AND status = 'active' AND limit_ms IS NOT NULL`)
    .all(userId);
  for (const s of active) {
    if (s.started_at + s.limit_ms <= now) {
      endSession(userId, s.id, "limit");
    }
  }
}

module.exports = { startSession, listActiveSessions, setLimit, endSession, sweepExpiredSessions, getSession };
