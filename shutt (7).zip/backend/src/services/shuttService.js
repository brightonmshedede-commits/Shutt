const crypto = require("crypto");
const db = require("../db");
const { findDuration, EMERGENCY_PRICE, FREE_DURATION_LIMIT_MS } = require("../utils/durations");
const notifications = require("./notificationService");
const payments = require("./paymentService");

function getUser(userId) {
  return db.prepare(`SELECT * FROM users WHERE id = ?`).get(userId);
}

function activeShuttForApp(userId, appId) {
  return db
    .prepare(`SELECT * FROM shutts WHERE user_id = ? AND app_id = ? AND status = 'active'`)
    .get(userId, appId);
}

function listActiveShutts(userId) {
  sweepExpired(userId);
  return db
    .prepare(`SELECT * FROM shutts WHERE user_id = ? AND status = 'active' ORDER BY unlock_at ASC`)
    .all(userId);
}

// Full history (every status) — the stats screen derives its charts and
// streak from this instead of the server pre-computing analytics.
function listAllShutts(userId) {
  sweepExpired(userId);
  return db
    .prepare(`SELECT * FROM shutts WHERE user_id = ? ORDER BY started_at DESC`)
    .all(userId);
}

// items: [{ appId, durationKey }] — one shared key across all items for "same
// duration for all", or a different key per item for the per-app case.
function createShutts(userId, items) {
  const user = getUser(userId);

  const resolved = items.map((it) => {
    const dur = findDuration(it.durationKey);
    if (!dur) {
      const err = new Error(`Unknown duration key: ${it.durationKey}`);
      err.status = 400;
      throw err;
    }
    return { appId: it.appId, dur };
  });

  const needsPremium = resolved.some((r) => r.dur.premium) && !user.is_premium;
  if (needsPremium) {
    const err = new Error("Premium required for one or more selected durations");
    err.status = 402;
    err.premiumRequired = true;
    err.plan = resolved.map((r) => ({ appId: r.appId, duration: r.dur }));
    throw err;
  }

  const now = Date.now();
  const insert = db.prepare(
    `INSERT INTO shutts (id, user_id, app_id, duration_key, duration_ms, started_at, unlock_at, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?)`
  );
  const created = [];

  const tx = db.transaction((rows) => {
    for (const r of rows) {
      // an app can only have one active shutt at a time — a fresh one replaces it
      const existing = activeShuttForApp(userId, r.appId);
      if (existing) {
        db.prepare(`UPDATE shutts SET status = 'ended' WHERE id = ?`).run(existing.id);
      }
      // a hard shutt supersedes any soft session running on the same app —
      // end it quietly (no "time's up" notification; that's only for a
      // session's own limit expiring on its own).
      db.prepare(`UPDATE sessions SET status = 'ended', ended_at = ? WHERE user_id = ? AND app_id = ? AND status = 'active'`).run(now, userId, r.appId);
      const id = crypto.randomUUID();
      insert.run(id, userId, r.appId, r.dur.key, r.dur.ms, now, now + r.dur.ms, now);
      created.push({ id, appId: r.appId, duration: r.dur, unlockAt: now + r.dur.ms });
    }
  });
  tx(resolved);

  const appRows = db.prepare(`SELECT id, name FROM apps WHERE user_id = ?`).all(userId);
  const nameOf = (id) => (appRows.find((a) => a.id === id) || {}).name || id;

  const grouped = {};
  created.forEach((c) => {
    const key = c.duration.label;
    (grouped[key] = grouped[key] || []).push(nameOf(c.appId));
  });
  const message = Object.entries(grouped)
    .map(([label, names]) => `${names.join(", ")} shutt for ${label}`)
    .join(" · ");
  notifications.push(userId, "shutt", message);

  return created;
}

function sweepExpired(userId) {
  const now = Date.now();
  const expired = db
    .prepare(`SELECT * FROM shutts WHERE user_id = ? AND status = 'active' AND unlock_at <= ?`)
    .all(userId, now);
  if (expired.length === 0) return;

  const appRows = db.prepare(`SELECT id, name FROM apps WHERE user_id = ?`).all(userId);
  const nameOf = (id) => (appRows.find((a) => a.id === id) || {}).name || id;

  const update = db.prepare(`UPDATE shutts SET status = 'ended' WHERE id = ?`);
  const tx = db.transaction((rows) => {
    for (const r of rows) update.run(r.id);
  });
  tx(expired);

  const names = expired.map((e) => nameOf(e.app_id));
  notifications.push(userId, "available", `${names.join(", ")} ${names.length > 1 ? "are" : "is"} available again`);
}

function emergencyUnlock(userId, shuttId) {
  const shutt = db
    .prepare(`SELECT * FROM shutts WHERE id = ? AND user_id = ? AND status = 'active'`)
    .get(shuttId, userId);
  if (!shutt) {
    const err = new Error("Active shutt not found");
    err.status = 404;
    throw err;
  }
  db.prepare(`UPDATE shutts SET status = 'emergency_unlocked' WHERE id = ?`).run(shutt.id);

  // Free-tier shutts (≤1 week) were never a paid restriction, so bailing out
  // of one early is free too. Only a Premium-length (>1 week) shutt charges
  // the emergency-unlock fee.
  const isFree = shutt.duration_ms <= FREE_DURATION_LIMIT_MS;
  const charge = isFree ? 0 : EMERGENCY_PRICE;
  payments.logPayment(userId, "emergency", charge, shutt.id);

  const app = db.prepare(`SELECT name FROM apps WHERE id = ?`).get(shutt.app_id);
  const message = isFree
    ? `${app ? app.name : "App"} unlocked early — free, it was a week or under`
    : `${app ? app.name : "App"} unlocked early — $${EMERGENCY_PRICE} charged`;
  notifications.push(userId, "emergency", message);

  return { ...shutt, emergencyCharge: charge };
}

module.exports = { listActiveShutts, listAllShutts, createShutts, sweepExpired, emergencyUnlock, activeShuttForApp };
