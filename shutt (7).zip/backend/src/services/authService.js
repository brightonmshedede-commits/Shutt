const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { jwtSecret, jwtExpiresIn } = require("../config");

function signToken(userId) {
  return jwt.sign({ sub: userId }, jwtSecret, { expiresIn: jwtExpiresIn });
}

function publicUser(u) {
  return { id: u.id, name: u.name || "", email: u.email, isPremium: !!u.is_premium, createdAt: u.created_at };
}

function signup(email, password, name) {
  const existing = db.prepare(`SELECT id FROM users WHERE email = ?`).get(email);
  if (existing) {
    const err = new Error("Email already registered");
    err.status = 409;
    throw err;
  }
  const id = crypto.randomUUID();
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(
    `INSERT INTO users (id, name, email, password_hash, is_premium, created_at) VALUES (?, ?, ?, ?, 0, ?)`
  ).run(id, name, email, hash, Date.now());
  const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(id);
  return { token: signToken(id), user: publicUser(user) };
}

function login(email, password) {
  const user = db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    const err = new Error("Invalid email or password");
    err.status = 401;
    throw err;
  }
  return { token: signToken(user.id), user: publicUser(user) };
}

function me(userId) {
  const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(userId);
  if (!user) {
    const err = new Error("User not found");
    err.status = 404;
    throw err;
  }
  return publicUser(user);
}

function changePassword(userId, currentPassword, newPassword) {
  const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(userId);
  if (!user) {
    const err = new Error("User not found");
    err.status = 404;
    throw err;
  }
  if (!bcrypt.compareSync(currentPassword, user.password_hash)) {
    const err = new Error("Current password is incorrect");
    err.status = 401;
    throw err;
  }
  if (String(newPassword).length < 6) {
    const err = new Error("New password must be at least 6 characters");
    err.status = 400;
    throw err;
  }
  const hash = bcrypt.hashSync(newPassword, 10);
  db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).run(hash, userId);
  return { ok: true };
}

// No email transport is configured in this project, so instead of silently
// pretending to send a reset email (which would never arrive), the reset
// code is returned directly in the response — same "simulated" spirit as
// the payments endpoints. Swap this for a real mailer in production.
function requestPasswordReset(email) {
  const user = db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
  if (!user) {
    // Same response shape whether or not the email is registered, so this
    // endpoint can't be used to test which emails have accounts.
    return { requested: true };
  }
  const token = crypto.randomBytes(3).toString("hex").toUpperCase(); // 6-char code
  const id = crypto.randomUUID();
  const expiresAt = Date.now() + 15 * 60 * 1000;
  db.prepare(
    `INSERT INTO password_resets (id, user_id, token, expires_at, used, created_at) VALUES (?, ?, ?, ?, 0, ?)`
  ).run(id, user.id, token, expiresAt, Date.now());
  return { requested: true, devToken: token, expiresAt };
}

function resetPassword(email, token, newPassword) {
  const user = db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
  if (!user) {
    const err = new Error("That code is invalid or has expired");
    err.status = 400;
    throw err;
  }
  const reset = db
    .prepare(`SELECT * FROM password_resets WHERE user_id = ? AND token = ? AND used = 0 ORDER BY created_at DESC LIMIT 1`)
    .get(user.id, String(token).toUpperCase());
  if (!reset || reset.expires_at < Date.now()) {
    const err = new Error("That code is invalid or has expired");
    err.status = 400;
    throw err;
  }
  if (String(newPassword).length < 6) {
    const err = new Error("New password must be at least 6 characters");
    err.status = 400;
    throw err;
  }
  const hash = bcrypt.hashSync(newPassword, 10);
  const applyReset = db.transaction(() => {
    db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).run(hash, user.id);
    db.prepare(`UPDATE password_resets SET used = 1 WHERE id = ?`).run(reset.id);
  });
  applyReset();
  return { ok: true };
}

module.exports = { signup, login, me, changePassword, requestPasswordReset, resetPassword, publicUser };
