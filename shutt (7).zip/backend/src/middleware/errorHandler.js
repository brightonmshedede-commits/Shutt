function notFound(req, res) {
  res.status(404).json({ error: "Not found" });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (process.env.NODE_ENV !== "test") {
    console.error(err);
  }
  const status = err.status || 500;
  const body = { error: err.message || "Internal server error" };
  if (err.premiumRequired) {
    body.premiumRequired = true;
    body.plan = err.plan;
  }
  res.status(status).json(body);
}

module.exports = { notFound, errorHandler };
