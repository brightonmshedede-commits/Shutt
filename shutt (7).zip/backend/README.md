# shutt backend

A real Express + SQLite API for the shutt prototype. It covers accounts,
hard "shutt" locks (with per-app durations), soft usage-nudge sessions,
Premium/Emergency payments, and notifications — everything the frontend
currently fakes in local React state.

## Stack (and why)

- **Node.js + Express** — same language as the frontend, nothing new to learn.
- **SQLite** via `better-sqlite3` — a single file on disk, zero setup, no
  separate database server to install or pay for. Good fit for a prototype;
  swapping to Postgres later mostly means changing `src/db.js`.
- **JWT auth** with `bcryptjs` password hashing — real auth, not a stub.
- **Payments are simulated.** There's no real card processing — `logPayment`
  just writes a row and fires a notification. It's shaped so a real Stripe
  integration (`stripe.paymentIntents.create(...)`) can drop into
  `src/services/paymentService.js` without touching any route or the rest of
  the app.
- **Password reset has no email transport.** `POST /api/auth/forgot-password`
  generates a real, time-limited (15 min) 6-character code and stores it in
  `password_resets`, but since no SMTP provider is configured it returns the
  code directly as `devToken` instead of emailing it — same "simulated"
  spirit as payments. Swap in a real mailer (e.g. `nodemailer` or a
  transactional email API) in `src/services/authService.js` and stop
  returning `devToken` once one exists.
- **The free/Premium line is exactly 1 week.** `FREE_DURATION_LIMIT_MS` in
  `src/utils/durations.js` is the single source of truth for this — every
  duration at or under it is free for everyone (including emergency
  unlocking a shutt set for a week or less, which costs nothing); anything
  longer requires Premium and, if emergency-unlocked, still charges the fee.
  Change that one constant to move the line.
- **No app is auto-seeded, and none can be.** New accounts start with zero
  tracked apps. There's no web API on any platform that lets a website read
  a phone's installed-app list — that's a privacy boundary in the browser
  itself, not a gap in this backend. Instead, `GET /api/apps/catalog`
  serves a curated list of ~32 real apps (`src/services/appService.js`) that
  the user picks from and imports via `POST /api/apps/import`; anything not
  in that list can still be added by hand via `POST /api/apps`.

**Important:** this backend cannot make WhatsApp or Instagram actually
unopenable on a phone — that needs OS-level permissions (iOS Screen Time API
/ Android Accessibility or UsageStats API) that only a native mobile client
can request. This backend is the source of truth for *state* (who's premium,
what's locked, for how long, what's been charged) that a real native client
would sync with and enforce locally.

## Setup

```bash
cd shutt-backend
npm install
cp .env.example .env
npm run dev
```

Server starts on `http://localhost:4000` (change `PORT` in `.env` if needed).
The SQLite file is created automatically at `./data/shutt.db` on first run.

## Quick test drive

```bash
# create an account (also seeds the 6 default apps)
curl -s -X POST http://localhost:4000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"hunter22"}'

# copy the "token" from the response into $TOKEN
export TOKEN="paste-token-here"

# see your apps
curl -s http://localhost:4000/api/apps -H "Authorization: Bearer $TOKEN"

# shutt one app for 30 minutes (see /api/meta for valid duration keys)
curl -s -X POST http://localhost:4000/api/shutts \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"items":[{"appId":"<an-app-id-from-above>","durationKey":"30m"}]}'

# check notifications
curl -s http://localhost:4000/api/notifications -H "Authorization: Bearer $TOKEN"
```

## Project layout

```
src/
  index.js              Express app + route mounting
  config.js              env var loading
  db.js                  SQLite connection + schema
  sweeper.js              background loop that expires shutts/sessions
  middleware/
    auth.js               JWT verification
    errorHandler.js        centralized error responses
  routes/                 thin HTTP layer — one file per resource
  services/               all business logic lives here
  utils/
    durations.js           duration catalog + pricing (single source of truth)
    asyncHandler.js         removes try/catch boilerplate in routes
```

## API reference

All endpoints except `/health`, `/api/auth/signup`, and `/api/auth/login`
require `Authorization: Bearer <token>`.

### Auth
| Method | Path | Body | Notes |
|---|---|---|---|
| POST | `/api/auth/signup` | `{ name, email, password }` | password min 6 chars, name required. No apps are seeded — see the note below. |
| POST | `/api/auth/login` | `{ email, password }` | |
| GET | `/api/auth/me` | — | current user |
| PATCH | `/api/auth/password` | `{ currentPassword, newPassword }` | newPassword min 6 chars |
| POST | `/api/auth/forgot-password` | `{ email }` | always `{ requested: true }`; also returns `devToken` (see note above) when the email exists |
| POST | `/api/auth/reset-password` | `{ email, token, newPassword }` | token is the 6-char code, valid 15 minutes, single-use |

### Apps
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/api/apps` | — | live status per app: `available` or `locked` + `unlockAt` |
| GET | `/api/apps/catalog` | — | curated list of ~32 real, well-known apps (see note below) to import from |
| POST | `/api/apps/import` | `{ ids: [catalogId, ...] }` | bulk-adds selected catalog apps; skips ones already added by name |
| POST | `/api/apps` | `{ name, category?, color?, iconKey? }` | add any other app by hand (not in the catalog) |

### Shutts (hard lock)
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/api/shutts/active` | — | all currently-active locks |
| GET | `/api/shutts` | — | full history (active, ended, emergency-unlocked) — powers the stats screen |
| POST | `/api/shutts` | `{ items: [{ appId, durationKey }] }` | one entry per app — same `durationKey` for all = shared duration, different keys = per-app durations. Durations of 1 week or less are free for everyone; longer than that returns `402` with `premiumRequired: true` if the user isn't premium. |
| POST | `/api/shutts/:id/emergency-unlock` | — | ends the lock immediately. Free if the shutt's duration is 1 week or under; charges `$3` only for a Premium-length (>1 week) shutt |

### Sessions (soft usage-nudge — different from a hard shutt)
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/api/sessions` | — | all currently-active soft sessions |
| POST | `/api/sessions` | `{ appId }` | call when an app is opened normally. Rejected with `409` if that app currently has an active shutt — start/end it there first |
| GET | `/api/sessions/:id` | — | check status/remaining |
| PATCH | `/api/sessions/:id/limit` | `{ durationKey }` or `{ limitMs }` | user chose a time limit for this session |
| POST | `/api/sessions/:id/end` | — | user closed the app manually |

A shutt and a session can't both be active on the same app at once: starting
a hard shutt quietly ends any running session for that app (no notification —
that's reserved for a session's own limit expiring naturally), and starting a
session is blocked outright if the app is currently shutt.

### Payments
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/api/payments` | — | billing history |
| POST | `/api/payments/premium` | — | one-time `$5`, unlocks all durations up to 1 year |

### Notifications
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/api/notifications` | — | `{ notifications, unread }` |
| POST | `/api/notifications/read-all` | — | marks everything read |

### Meta
| Method | Path | Notes |
|---|---|---|
| GET | `/api/meta` | full duration catalog, nudge-duration presets, and current pricing — fetch this instead of hardcoding durations/prices in a client |

## Wiring this into the React prototype

The frontend currently keeps everything in local `useState`. To connect it
for real: replace the local `apps`/`notifications`/`payments` state with
`fetch` calls to these endpoints, store the JWT (e.g. in memory or a secure
cookie — avoid `localStorage` if this ever runs inside the Claude artifact
sandbox, since browser storage APIs are blocked there), and swap the local
`setInterval` countdown math for polling `GET /api/apps` and
`GET /api/notifications` every few seconds, or move to WebSockets later if
you want push updates instead of polling.
