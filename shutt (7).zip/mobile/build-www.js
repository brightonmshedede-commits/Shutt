// Copies the compiled ../web-app into ./www — Capacitor's expected webDir.
// Plain Node, no dependencies, so it works even before `npm install` here
// has finished. Re-run this (or `npm run cap:sync`, which calls it for you)
// any time frontend/shutt.jsx changes and web-app/index.html gets
// recompiled from it.
const fs = require("fs");
const path = require("path");

const SRC = path.join(__dirname, "..", "web-app");
const DEST = path.join(__dirname, "www");

function copyRecursive(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    fs.copyFileSync(src, dest);
  }
}

if (!fs.existsSync(SRC)) {
  console.error(`Expected ${SRC} to exist — run this from inside mobile/.`);
  process.exit(1);
}

fs.rmSync(DEST, { recursive: true, force: true });
copyRecursive(SRC, DEST);
console.log(`Copied ${SRC} -> ${DEST}`);
